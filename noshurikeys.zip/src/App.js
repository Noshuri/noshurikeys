
export default function Home() {
  const currentYear = new Date().getFullYear();

  return (
    <main className="min-h-screen bg-black text-white font-sans flex flex-col items-center justify-center p-6">
      <h1 className="text-4xl font-bold mb-4">NoShuriKeys 🔑</h1>
      <p className="text-lg mb-8 text-center max-w-xl">
        Welcome to NoShuriKeys — your trusted key source for exclusive Roblox scripts. Secure payments. Fast delivery.
      </p>

      <a
        href="https://noshurikeys.sell.app"
        className="bg-white text-black font-semibold py-2 px-6 rounded-2xl shadow mb-10 hover:bg-gray-200 transition"
        target="_blank"
        rel="noopener noreferrer"
      >
        💸 Buy Now
      </a>

      <section className="w-full max-w-2xl bg-gray-900 rounded-xl p-6 shadow-lg mb-10">
        <h2 className="text-2xl font-semibold mb-4">How to Use</h2>
        <ol className="list-decimal list-inside space-y-2">
          <li>Run the script in your Roblox executor (e.g. Fluxus, Synapse).</li>
          <li>You'll be prompted to get a key — click the link to purchase.</li>
          <li>Once purchased, join our Discord to redeem it with support.</li>
        </ol>
      </section>

      <section className="w-full max-w-2xl bg-gray-900 rounded-xl p-6 shadow-lg">
        <h2 className="text-2xl font-semibold mb-4">Need Help? Join the Discord</h2>
        <a
          href="https://discord.gg/GpQtSpwmfY"
          className="inline-block bg-indigo-600 hover:bg-indigo-700 text-white py-2 px-4 rounded-lg transition"
          target="_blank"
          rel="noopener noreferrer"
        >
          🔗 Join Now
        </a>
      </section>

      <footer className="mt-12 text-sm text-gray-500">© {currentYear} NoShuriKeys</footer>
    </main>
  );
}
